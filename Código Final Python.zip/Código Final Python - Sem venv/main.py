# Importação das biblioteca e funções
import timeit
from readmesh import *
from view import *
from MEF import *

# Início da contagem do tempo de execução do código
inicio = timeit.default_timer()

# Atribuição de variáveis de acordo com a saída de dados da função "readmesh"
[NODES,coord_nodes,num_restrs,restrs,num_isomat,props,num_thick,elem_nodes,NELE,connect,Dofnode,dofelem,NDoF,forces,nstep,planestress,NGP,tolD,MaxIter] = readmesh('Entrada de dados - FEMEP.txt', "Entrada de dados - Análise EP.nf")

# Atribuição de variáveis de acordo com a saída de dados da função "dofdrive"
assmtrx = dofdrive(elem_nodes, NELE, connect, dofelem)
XY = coord_nodes[:,[1,2]]
X = coord_nodes[:,[1]]
Y = coord_nodes[:,[2]]

# Atribuição de variáveis auxiliares de acordo com a saída de dados da função "readmesh"
E = props[0, 0]
v = props[0, 1]
t = props[0, 2]
fy = props[0, 3]

# Atribuição de variáveis de acordo com a saída de dados da função "PtsGauss1d"
[csi, w] = PtsGauss1d(NGP)

# Atribuição de variáveis de acordo com a saída de dados da função "MEF_ep"
[D, sigma_total, j2Elem] = MEF_ep(NDoF, nstep, NELE, connect, elem_nodes, NGP, X, Y, dofelem, t, v, E, planestress, assmtrx, fy, forces, restrs, tolD, MaxIter)

# Relatório dos dados de saída da função "MEF_ep"
print("Deslocamentos Nodais:\n",D,"\n", "Tensões Finais:\n", sigma_total)

# Atribuição de variáveis de acordo com a saída de dados da função "viewmesh" e "MEF_ep"
viewdeformedmesh(XY, connect, D, 10,elem_nodes)

viewcolormesh(XY, connect, elem_nodes, j2Elem)

# Fim da contagem do tempo de execução do código
fim = timeit.default_timer()

print("Tempo de execução: {} s".format(fim-inicio))